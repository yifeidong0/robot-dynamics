function T3E = getTransform3F_solution(l5)
 
  T3E = [   1 0 0 l5;
            0 1 0 0;
            0 0 1 0;
            0 0 0 1];
end